/**
 * @returns {Math}
 */
var Math = {
}
/**
 * @syntax E
 * @returns {Number}
 * @static
 */
Math.E = new Number();

/**
 * @syntax LN2
 * @returns {Number}
 * @static
 */
Math.LN2 = new Number();

/**
 * @syntax atan(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.atan = function(x) {};

/**
 * @syntax pow(x,y)
 * @param {Number} x
 * @param {Number} y
 * @returns {Number}
 * @static
 */
Math.pow = function(x, y) {};

/**
 * @syntax asin(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.asin = function(x) {};

/**
 * @syntax cos(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.cos = function(x) {};

/**
 * @syntax ceil(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.ceil = function(x) {};

/**
 * @syntax round(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.round = function(x) {};

/**
 * @syntax atan2(y,x)
 * @param {Number} y
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.atan2 = function(y, x) {};

/**
 * @syntax abs(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.abs = function(x) {};

/**
 * @syntax SQRT1_2
 * @returns {Number}
 * @static
 */
Math.SQRT1_2 = new Number();

/**
 * @syntax acos(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.acos = function(x) {};

/**
 * @syntax min([value1[,value2[,…]]])
 * @param {Number} 
 * @returns {Number}
 * @static
 */
Math.min = function() {};

/**
 * @syntax LN10
 * @returns {Number}
 * @static
 */
Math.LN10 = new Number();

/**
 * @syntax max([value1[,value2[,…]]])
 * @param {Number} 
 * @returns {Number}
 * @static
 */
Math.max = function() {};

/**
 * @syntax sqrt(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.sqrt = function(x) {};

/**
 * @syntax random()
 * @returns {Number}
 * @static
 */
Math.random = function() {};

/**
 * @syntax SQRT2
 * @returns {Number}
 * @static
 */
Math.SQRT2 = new Number();

/**
 * @syntax log(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.log = function(x) {};

/**
 * @syntax exp(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.exp = function(x) {};

/**
 * @syntax floor(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.floor = function(x) {};

/**
 * @syntax PI
 * @returns {Number}
 * @static
 */
Math.PI = new Number();

/**
 * @syntax sin(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.sin = function(x) {};

/**
 * @syntax tan(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.tan = function(x) {};

/**
 * @syntax LOG10E
 * @returns {Number}
 * @static
 */
Math.LOG10E = new Number();

/**
 * @syntax LOG2E
 * @returns {Number}
 * @static
 */
Math.LOG2E = new Number();

/**
 * Represents the Math prototype object.
 * @syntax Math.prototype
 * @static
 */
Math.prototype;

