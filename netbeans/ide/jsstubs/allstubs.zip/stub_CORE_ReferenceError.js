/**
 * @syntax new ReferenceError([message[, fileName[, linenumber]]])
 * @param {String} 
 * @returns {Error}
 */
function ReferenceError() {
}
/**
 * @returns {String}
 */
ReferenceError.prototype.name = new String();

/**
 * @returns {Function}
 */
ReferenceError.prototype.constructor = new Function();

/**
 * @returns {Object}
 * @static
 */
ReferenceError.prototype;

