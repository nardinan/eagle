/**
 * Client-side image map area definition. See the AREA element definition in HTML 4.01.
 */
var HTMLAreaElement = {
}
/**
 * A single character access key to give access to the form control. See the accesskey attribute definition in HTML 4.01.
 * @syntax hTMLAreaElement.accessKey
 * @returns {String} 
 */
HTMLAreaElement.prototype.accessKey = new String();

/**
 * Comma-separated list of lengths, defining an active region geometry. See also shape for the shape of the region. See the coords attribute definition in HTML 4.01.
 * @syntax hTMLAreaElement.coords
 * @returns {String} 
 */
HTMLAreaElement.prototype.coords = new String();

/**
 * Specifies that this area is inactive, i.e., has no associated action. See the nohref attribute definition in HTML 4.01.
 * @syntax hTMLAreaElement.noHref
 * @returns {boolean} 
 */
HTMLAreaElement.prototype.noHref = new boolean();

/**
 * Alternate text for user agents not rendering the normal content of this element. See the alt attribute definition in HTML 4.01.
 * @syntax hTMLAreaElement.alt
 * @returns {String} 
 */
HTMLAreaElement.prototype.alt = new String();

/**
 * Index that represents the element's position in the tabbing order. See the tabindex attribute definition in HTML 4.01.
 * @syntax hTMLAreaElement.tabIndex
 * @returns {Number} 
 */
HTMLAreaElement.prototype.tabIndex = new Number();

/**
 * Frame to render the resource in. See the target attribute definition in HTML 4.01.
 * @syntax hTMLAreaElement.target
 * @returns {String} 
 */
HTMLAreaElement.prototype.target = new String();

/**
 * The shape of the active area. The coordinates are given by coords. See the shape attribute definition in HTML 4.01.
 * @syntax hTMLAreaElement.shape
 * @returns {String} 
 */
HTMLAreaElement.prototype.shape = new String();

/**
 * The URI [IETF RFC 2396] of the linked resource. See the href attribute definition in HTML 4.01.
 * @syntax hTMLAreaElement.href
 * @returns {String} 
 */
HTMLAreaElement.prototype.href = new String();

/**
 * Represents the HTMLAreaElement prototype object.
 * @syntax HTMLAreaElement.prototype
 * @static
 */
HTMLAreaElement.prototype;

