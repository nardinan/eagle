/**
 * Parameters fed to the OBJECT element. See the PARAM element definition in HTML 4.01.
 */
var HTMLParamElement = {
}
/**
 * The name of a run-time parameter. See the name attribute definition in HTML 4.01.
 * @syntax hTMLParamElement.name
 * @returns {String} 
 */
HTMLParamElement.prototype.name = new String();

/**
 * The value of a run-time parameter. See the value attribute definition in HTML 4.01.
 * @syntax hTMLParamElement.value
 * @returns {String} 
 */
HTMLParamElement.prototype.value = new String();

/**
 * Information about the meaning of the value attribute value. See the valuetype attribute definition in HTML 4.01.
 * @syntax hTMLParamElement.valueType
 * @returns {String} 
 */
HTMLParamElement.prototype.valueType = new String();

/**
 * Content type for the value attribute when valuetype has the value "ref". See the type attribute definition in HTML 4.01.
 * @syntax hTMLParamElement.type
 * @returns {String} 
 */
HTMLParamElement.prototype.type = new String();

/**
 * Represents the HTMLParamElement prototype object.
 * @syntax HTMLParamElement.prototype
 * @static
 */
HTMLParamElement.prototype;

