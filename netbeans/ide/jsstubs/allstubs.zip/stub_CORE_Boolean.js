/**
 * @syntax new Boolean(value)
 * @param {Object} value
 * @returns {Boolean}
 */
function Boolean(value) {
}
/**
 * @syntax toString()
 * @returns {String}
 */
Boolean.prototype.toString = function() {};

/**
 * @syntax valueOf()
 * @returns {Boolean}
 */
Boolean.prototype.valueOf = function() {};

/**
 * @syntax constructor
 * @returns {Function}
 */
Boolean.prototype.constructor = new Function();

/**
 * @syntax prototype
 * @returns {Object}
 * @static
 */
Boolean.prototype;

