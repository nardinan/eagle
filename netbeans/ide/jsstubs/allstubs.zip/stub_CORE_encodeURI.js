/**
 * @syntax encodeURI(URI)
 * @param {String} URI
 * @returns {String}
 */
function encodeURI(URI) {};
