/**
 * @syntax parseFloat(string)
 * @param {String} string
 * @returns {Number}
 */
function parseFloat(string) {};
