/**
 * Inline subwindows. See the IFRAME element definition in HTML 4.01.
 */
var HTMLIFrameElement = {
}
/**
 * Frame height. See the height attribute definition in HTML 4.01.
 * @syntax hTMLIFrameElement.height
 * @returns {String} 
 */
HTMLIFrameElement.prototype.height = new String();

/**
 * Specify whether or not the frame should have scrollbars. See the scrolling attribute definition in HTML 4.01.
 * @syntax hTMLIFrameElement.scrolling
 * @returns {String} 
 */
HTMLIFrameElement.prototype.scrolling = new String();

/**
 * Aligns this object (vertically or horizontally) with respect to its surrounding text. See the align attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLIFrameElement.align
 * @returns {String} 
 */
HTMLIFrameElement.prototype.align = new String();

/**
 * The frame name (object of the target attribute). See the name attribute definition in HTML 4.01.
 * @syntax hTMLIFrameElement.name
 * @returns {String} 
 */
HTMLIFrameElement.prototype.name = new String();

/**
 * Frame width. See the width attribute definition in HTML 4.01.
 * @syntax hTMLIFrameElement.width
 * @returns {String} 
 */
HTMLIFrameElement.prototype.width = new String();

/**
 * URI [IETF RFC 2396] designating a long description of this image or frame. See the longdesc attribute definition in HTML 4.01.
 * @syntax hTMLIFrameElement.longDesc
 * @returns {String} 
 */
HTMLIFrameElement.prototype.longDesc = new String();

/**
 * Frame margin height, in pixels. See the marginheight attribute definition in HTML 4.01.
 * @syntax hTMLIFrameElement.marginHeight
 * @returns {String} 
 */
HTMLIFrameElement.prototype.marginHeight = new String();

/**
 * Frame margin width, in pixels. See the marginwidth attribute definition in HTML 4.01.
 * @syntax hTMLIFrameElement.marginWidth
 * @returns {String} 
 */
HTMLIFrameElement.prototype.marginWidth = new String();

/**
 * Request frame borders. See the frameborder attribute definition in HTML 4.01.
 * @syntax hTMLIFrameElement.frameBorder
 * @returns {String} 
 */
HTMLIFrameElement.prototype.frameBorder = new String();

/**
 * A URI [IETF RFC 2396] designating the initial frame contents. See the src attribute definition in HTML 4.01.
 * @syntax hTMLIFrameElement.src
 * @returns {String} 
 */
HTMLIFrameElement.prototype.src = new String();

/**
 * The document this frame contains, if there is any and it is available, or null otherwise.
 * @syntax hTMLIFrameElement.contentDocument
 * @returns {Document} 
 */
HTMLIFrameElement.prototype.contentDocument = new Document();

/**
 * Represents the HTMLIFrameElement prototype object.
 * @syntax HTMLIFrameElement.prototype
 * @static
 */
HTMLIFrameElement.prototype;

