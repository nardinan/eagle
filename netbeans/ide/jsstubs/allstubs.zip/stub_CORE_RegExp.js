/**
 * @syntax RegExp(pattern [, flags])<br> /pattern/flags
 * @param {String} pattern
 * @returns {RegExp}
 */
function RegExp(pattern ) {
}
/**
 * @syntax lastIndex
 * @returns {Number}
 */
RegExp.prototype.lastIndex = new Number();

/**
 * @syntax source
 * @returns {String}
 */
RegExp.prototype.source = new String();

/**
 * @syntax multiline
 * @returns {Boolean}
 */
RegExp.prototype.multiline = new Boolean();

/**
 * @syntax test(string)
 * @param {String} string
 * @returns {Boolean}
 */
RegExp.prototype.test = function(string) {};

/**
 * @syntax regExp.compile(regexp, modifier)
 * @param {RegExp} regexp
 * @param {String} modifier
 * @returns {RegExp}
 */
RegExp.prototype.compile = function(regexp,  modifier) {};

/**
 * @syntax global
 * @returns {Boolean}
 */
RegExp.prototype.global = new Boolean();

/**
 * @syntax exec(string)
 * @param {String} string
 * @returns {Array}
 */
RegExp.prototype.exec = function(string) {};

/**
 * @syntax toString()
 * @returns {String}
 */
RegExp.prototype.toString = function() {};

/**
 * @syntax ignoreCase
 * @returns {Boolean}
 */
RegExp.prototype.ignoreCase = new Boolean();

/**
 * @syntax constructor
 * @returns {Function}
 */
RegExp.prototype.constructor = new Function();

/**
 * @syntax prototype
 * @returns {Object}
 * @static
 */
RegExp.prototype;

