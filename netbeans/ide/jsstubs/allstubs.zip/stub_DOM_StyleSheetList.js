/**
 * The StyleSheetList interface provides the abstraction of an ordered collection of style sheets.The items in the StyleSheetList are accessible via an integral index, starting from 0.
 */
var StyleSheetList = {
}
/**
 * Used to retrieve a style sheet by ordinal index. If index is greater than or equal to the number of style sheets in the list, this returns null.
 * @syntax styleSheetList.item(index)
 * @param {Number} index Index into the collection
 * @returns {StyleSheet} The style sheet at the index position in the StyleSheetList, or null if that is not a valid index.
 */
StyleSheetList.prototype.item = function(index) {};

/**
 * The number of StyleSheets in the list. The range of valid child stylesheet indices is 0 to length-1 inclusive.
 * @syntax styleSheetList.length
 * @returns {Number} 
 */
StyleSheetList.prototype.length = new Number();

/**
 * Represents the StyleSheetList prototype object.
 * @syntax StyleSheetList.prototype
 * @static
 */
StyleSheetList.prototype;

