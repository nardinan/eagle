/**
 */
var Window = {
}
/**
 * @returns {Window}
 */
Window.prototype.window = new Window();

/**
 * @returns {Location}
 */
Window.prototype.location = new Location();

/**
 * @returns {Number}
 */
Window.prototype.setTimeout = function() {};

/**
 * @returns {undefined}
 */
Window.prototype.clearInterval = function() {};

/**
 * @returns {DOMString}
 */
Window.prototype.name = new DOMString();

/**
 * @returns {Element}
 */
Window.prototype.frameElement = new Element();

/**
 * @returns {Window}
 */
Window.prototype.parent = new Window();

/**
 * @returns {undefined}
 */
Window.prototype.clearTimeout = function() {};

/**
 * @returns {Window}
 */
Window.prototype.self = new Window();

/**
 * @returns {Number}
 */
Window.prototype.setInterval = function() {};

/**
 * @returns {Window}
 */
Window.prototype.top = new Window();

/**
 * Represents the Window prototype object.
 * @syntax Window.prototype
 * @static
 */
Window.prototype;

