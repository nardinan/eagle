/**
 * Inline style information attached to elements is exposed through the style attribute. This represents the contents of the STYLE attribute for HTML elements (or elements in other schemas or DTDs which use the STYLE attribute in the same way). The expectation is that an instance of the ElementCSSInlineStyle interface can be obtained by using binding-specific casting methods on an instance of the Element interface when the element supports inline CSS style informations.
 */
var ElementCSSInlineStyle = {
}
/**
 * The style attribute.
 * @syntax elementCSSInlineStyle.style
 * @returns {CSSStyleDeclaration} 
 */
ElementCSSInlineStyle.prototype.style = new CSSStyleDeclaration();

/**
 * Represents the ElementCSSInlineStyle prototype object.
 * @syntax ElementCSSInlineStyle.prototype
 * @static
 */
ElementCSSInlineStyle.prototype;

