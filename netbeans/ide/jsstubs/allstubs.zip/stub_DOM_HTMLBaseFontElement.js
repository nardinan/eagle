/**
 * Base font. See the BASEFONT element definition in HTML 4.01. This element is deprecated in HTML 4.01.
 */
var HTMLBaseFontElement = {
}
/**
 * Font face identifier. See the face attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLBaseFontElement.face
 * @returns {String} 
 */
HTMLBaseFontElement.prototype.face = new String();

/**
 * Font color. See the color attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLBaseFontElement.color
 * @returns {String} 
 */
HTMLBaseFontElement.prototype.color = new String();

/**
 * Computed font size. See the size attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLBaseFontElement.size
 * @returns {Number} 
 */
HTMLBaseFontElement.prototype.size = new Number();

/**
 * Represents the HTMLBaseFontElement prototype object.
 * @syntax HTMLBaseFontElement.prototype
 * @static
 */
HTMLBaseFontElement.prototype;

