/**
 * The NodeList interface provides the abstraction of an ordered collection of nodes, without defining or constraining how this collection is implemented. NodeList objects in the DOM are live.The items in the NodeList are accessible via an integral index, starting from 0.
 */
var NodeList = {
}
/**
 * Returns the indexth item in the collection. If index is greater than or equal to the number of nodes in the list, this returns null.
 * @syntax nodeList.item(index)
 * @param {Number} index Index into the collection.
 * @returns {Node} The node at the indexth position in the NodeList, or null if that is not a valid index.
 */
NodeList.prototype.item = function(index) {};

/**
 * The number of nodes in the list. The range of valid child node indices is 0 to length-1 inclusive.
 * @syntax nodeList.length
 * @returns {Number} 
 */
NodeList.prototype.length = new Number();

/**
 * Represents the NodeList prototype object.
 * @syntax NodeList.prototype
 * @static
 */
NodeList.prototype;

