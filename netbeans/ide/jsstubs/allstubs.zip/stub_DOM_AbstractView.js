/**
 * A base interface that all views shall derive from.
 */
var AbstractView = {
}
/**
 * The source DocumentView of which this is an AbstractView.
 * @syntax abstractView.document
 * @returns {DocumentView} 
 */
AbstractView.prototype.document = new DocumentView();

/**
 * Represents the AbstractView prototype object.
 * @syntax AbstractView.prototype
 * @static
 */
AbstractView.prototype;

