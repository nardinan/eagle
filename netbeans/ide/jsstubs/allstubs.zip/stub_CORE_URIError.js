/**
 * @syntax new URIError([message[, fileName[, lineNumber]]])
 * @param {String} 
 * @returns {Error}
 */
function URIError() {
}
/**
 * @returns {String}
 * @static
 */
URIError.name = new String();

/**
 * @returns {Function}
 * @static
 */
URIError.constructor = new Function();

/**
 * @returns {Object}
 * @static
 */
URIError.prototype;

