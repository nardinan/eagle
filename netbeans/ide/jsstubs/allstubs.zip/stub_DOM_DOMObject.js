/**
 * A DOMObject represents an object reference.
 */
var DOMObject = {
}
/**
 * Represents the DOMObject prototype object.
 * @syntax DOMObject.prototype
 * @static
 */
DOMObject.prototype;

