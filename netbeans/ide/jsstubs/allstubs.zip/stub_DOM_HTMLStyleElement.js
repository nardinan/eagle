/**
 * Style information. See the STYLE element definition in HTML 4.01, the CSS module [DOM Level 2 Style Sheets and CSS] and the LinkStyle interface in the StyleSheets module [DOM Level 2 Style Sheets and CSS].
 */
var HTMLStyleElement = {
}
/**
 * The content type of the style sheet language. See the type attribute definition in HTML 4.01.
 * @syntax hTMLStyleElement.type
 * @returns {String} 
 */
HTMLStyleElement.prototype.type = new String();

/**
 * Designed for use with one or more target media. See the media attribute definition in HTML 4.01.
 * @syntax hTMLStyleElement.media
 * @returns {String} 
 */
HTMLStyleElement.prototype.media = new String();

/**
 * Enables/disables the style sheet.
 * @syntax hTMLStyleElement.disabled
 * @returns {boolean} 
 */
HTMLStyleElement.prototype.disabled = new boolean();

/**
 * Represents the HTMLStyleElement prototype object.
 * @syntax HTMLStyleElement.prototype
 * @static
 */
HTMLStyleElement.prototype;

